<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        <script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>
       

</head>
<body align="center">
<nav>
		<div class="menu">
			<a href="homepage.php">Home</a>
			<a href="orderpage.php">Order</a>
			<a href="Aboutuspage.php">AboutUs</a>
		</div>
    </nav>
 <h1>Welcome to JustBake</h1>
<?php
include("Database.php");

function addCustomCakeDetails($themeid,$caketype,$cakesize,$cakeshape,$tires,$color,$flavour,
    $filling,$Icing,$writingcolor,$Wirting,$note
    ){
    
    $dbInstance=new DatabaseClass();
    $insertQuery="INSERT INTO custom (Ocassion,Caketype,CakeSize,Cakeshape,Nooftiers,Color,Flavour,Filling,Icing,Writing_Color,Writing,Notes)
     VALUES ('$themeid','$caketype','$cakesize','$cakeshape','$tires','$color','$flavour','$filling','$Icing','$writingcolor','$Wirting','$note')";
    //echo "$insertQuery";
    $result=$dbInstance->ActionQuery($insertQuery);
    //echo "$result";
    if($result)
    {
        return 1;
    }
    else
    {
        return $dbInstance;
    }
}

function calculateCost($themeid,$caketype,$cakesize,$cakeshape,$tires,$color,$flavour,
    $filling,$Icing,$writingcolor,$Wirting,$note
    ){
    $x="";$y="";$z="";
    
        switch($cakesize){
            case "6inch":
                $x="20";
                break;
            case "8inch":
                $x="25";
                break;
            case "10inch":
                $x="30";
                break;
            case "Halfsheet":
                $x="35";
                break;
            case "Fullsheet":
                $x="40";
                break;
            case "Customsize":
                $x="50";
                break;         
        }
        if( $tires>1){
            $y=($tires-1)*5;
        }else{$y="0";}
        if($note!=""){
            $z="2";
        }else{$z="0";}
        $sum= $x + $y + $z;
      echo "<p><span style='padding:10%;color:black; align:center;'>Total cost= $".$sum."</span></p> ";  
}


if($_SERVER['REQUEST_METHOD']=='POST'){ 
    if(isset($_POST["themeid"])&& isset($_POST["caketype"]) && 
        isset($_POST["cakesize"]) && isset($_POST["cakeshape"]) &&
        isset($_POST["tires"]) && isset($_POST["color"]) &&
        isset($_POST["flavour"]) && isset($_POST["filling"]) &&
        isset($_POST["Icing"]) && isset($_POST["writingcolor"]) &&
        isset($_POST["Wirting"])){
        if($_POST['themeid']!=""&& $_POST['caketype']!=""&& $_POST['cakesize']!="" && $_POST['cakeshape']!="" && $_POST['tires']!=""
            && $_POST['color']!="" && $_POST['flavour']!=""&& $_POST['filling']!=""&& $_POST['Icing']!=""&& $_POST['writingcolor']!=""
            && $_POST['Wirting']!=""){
            
            $themeid=$_POST['themeid'];
            $caketype=$_POST['caketype'];
            $cakesize=$_POST['cakesize'];
            $cakeshape=$_POST['cakeshape'];
            $tires=$_POST['tires'];
            $color=$_POST['color'];
            $flavour=$_POST['flavour'];
            $filling=$_POST['filling'];
            $Icing=$_POST['Icing'];
            $writingcolor=$_POST['writingcolor'];
            $Wirting=$_POST['Wirting'];
            $note=$_POST['note'];
            
            if($themeid!=""&& $caketype!=""&& $cakesize!="" && $cakeshape!="" && $tires!="" 
                && $color!="" && $flavour!=""&& $filling!=""&& $Icing!=""&& $writingcolor!="" 
                && $Wirting!="") {
                
                    $customDetails=addCustomCakeDetails($themeid,$caketype,$cakesize,$cakeshape,$tires,$color,$flavour,
                        $filling,$Icing,$writingcolor,$Wirting,$note);
                if($customDetails==1)
                {
                    calculateCost($themeid,$caketype,$cakesize,$cakeshape,$tires,$color,$flavour,
                        $filling,$Icing,$writingcolor,$Wirting,$note);
                    echo "<span style='padding:10%;color:black; align:center;'>Custom cake details added successfully..! </span>";
                    echo "<p><span style='padding:10%;color:black; align:center;'>Your cake for ".$themeid." </span></p>";
                    echo "<p><span style='padding:10%;color:black; align:center;'>Size is  ".$cakesize." </span></p>";
                    echo "<p><span style='padding:10%;color:black; align:center;'>Flavour of  ".$flavour."</span></p>";
                   
                    
                }
                
                else
                {
                    echo "<span style='padding:10%;color:black;align:center;'>Cake details cannot be added! </span>";
                }
                
            } else {
                echo"<span style='padding:10%;color:black;align:center;'>Please enter all details</span>";
            }
        }
        else {
            echo"<span style='padding:10%;color:black;align:center;'>Please enter all details</span>";
        }
    }
    else {
        echo"<span style='padding:10%;color:black;align:center;'>Please enter all details</span>";
    }
}

?>
<form>
       <button type= "button"class="input-field"  onclick= "window.location.href='paymentpage.php'"  name="ok" id="okid" >ok</button>
       <button type= "button" name="back" id="btn"  onclick="window.location.href='custompage.php';" >back</button> 

</form>   
</body>
</html>
 
 

