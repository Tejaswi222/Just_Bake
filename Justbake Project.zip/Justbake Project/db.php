
<?php 
$host="localhost";
$dbname="test";
$username="root";
$password="";
?>