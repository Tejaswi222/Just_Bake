
<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        <script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>

</head>
<body align="center">
	<nav>
		<div class="menu">
			<a href="homepage.php">Home</a>
			<a href="orderpage.php">Order</a>
			<a href="Aboutuspage.php">AboutUs</a>
		</div>
    </nav>
	 <h1>Welcome to JustBake</h1>
	 <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="cupcake.jpg" style="width:40%">
  
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="slicedcake.jpg" style="width:50%">
 
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="Childerncakes.jpg" style="width:50%">
 
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="furitcake.jpg" style="width:50%">
  
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="weddingcake.jpg" style="width:50%">
 
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
<form action="orderpage.php" method="POST">
     <h2> For Cost Details: <input type="submit" name="orderbtn" value="click here"></h2>
</form>
</body>
</html>




