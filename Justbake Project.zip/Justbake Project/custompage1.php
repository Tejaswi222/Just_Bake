<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        <script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>
       

</head>
<body align="center">
	
	 <h1>Custom your cake with your  own options</h1>
     
	  <div  class=formpage>
        <form action="cost1.php" method="POST">
        <p>Ocassion:<input type="text" class="input-field" name="themeid" ></p>
           	<p align="center"><u>Cake Type</u></p>
           <input type="radio" name="caketype" id="egg" value="egg">
        <label for="egg">Egg</label>
          <input type="radio" name="caketype" id="eggless" value="eggless">
        <label for="egg">EggLess</label><br><br>
        
           <p>No.of cakes:<input type="text" name="cakes" id="cakesid"></p><br>
        <label>Flavours</label>
            <select name="flavour">
                     <option value ="Chocolate">Chocolate </option>
                    <option value ="Vanilla">Vanilla</option>
                    <option value ="RedVelvet">RedVelvet</option>
                    <option value ="Pineapple">Pineapple</option>
                    <option value ="BlackForest">BlackForest</option>
                    <option value ="Strawberry">Strawberry</option>
                  </select>
                  

        <label>Icing</label>
            <select name="Icing">
                    <option value ="Butter Cream">Butter Cream</option>
                    <option value ="Whipped Cream">Whipped Cream</option>
                    <option value ="Royal Icing">Royal Icing</option>
                  </select><br><br>
        <lable for="Note">Special Instructions</lable>
             <textarea name="note" id="noteid" rows="5" cols="40"></textarea><br><br>
                 <input type= "submit" name="submit" id="submitid" value="Place Order" >            
     <input type= "button" name="backbtn" id="btnid" value="back" onclick="window.location.href='http://localhost/JustBake%20project/orderpage.php';" > 
          </form>    
    </div>
   

                   
     </body>
     </html>