<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        

</head>
<body align="center">
	<nav>
		<div class="menu">
			<a href="homepage.php">Home</a>
			<a href="orderpage.php">Order</a>
			<a href="Aboutuspage.php">AboutUs</a>
		</div>
    </nav>
  
	 <h1>Welcome to JustBake</h1>
	
	<table>
	 <tr>
	 	<th>Regular Cake</th>
	 	<th>Price 6/8/10/half/full/custom</th>
	 	<th>Spl decoration</th>
	 </tr>
	 <tr>
	 	<td>Single tier</td>
	 	<td>$20/$25/$30/$35/$40/50</td>
	 	<td>$2 Extra on total cost</td>
	 	<h3 colspan="3" >For each extra tier $5 extra on the single tier price</h3>
	 </tr>
	</table><br>
	<form action="custompage.php"method="POST">
	<input type="submit" name="cake" value="Custom your cake"><br><br>
</form>
	

	<table>
	 <tr>
	 	<th>Cup Cake</th>
	 	<th>Price</th>
	 	<th>Spl decoration</th>
	 </tr>
	 <tr>
	 	<td>Cupcake</td>
	 	<td>$3 for each cupcake</td>
	 	<td>$1 extra on total cost</td>
	 	
	 </tr>
	 </table><br>
	 <form action="custompage1.php" method="POST">
      <input type="submit" name="cupcake" value="Custom your cupcake"><br>
    </form>
</body>
</html>