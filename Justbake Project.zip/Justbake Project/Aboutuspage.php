<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        <script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>

</head>
<body align="center">
	<nav>
		<div class="menu">
			<a href="homepage.php">Home</a>
			<a href="orderpage.php">Order</a>
			<a href="Aboutuspage.php">AboutUs</a>
		</div>
    </nav>
     <h1> About JustBake</h1>
     <br>
    <p style="width:50%; margin-left:25%;">One of the key factors in The Just Bake Bakerys 
    prosperity has been its ethos that cakes taste best when they
     have been naturally heated utilizing the very same  fixings and 
     methods as those utilized in home preparing. Consequently, 
     every single Just Bake Bakery branch has its own kitchen 
     and a group of occupant master pastry specialists 
     and cake decorators.</p>
     <br>
    <p style='color:red;align:center;'><u>Created By </u> </p>
     <p style='color:red;align:center;'>Sai Tejaswi Bezawada </p>
     <p style='color:red;align:center;'>Id: 700702402</p>
    </body>
    
    </html>