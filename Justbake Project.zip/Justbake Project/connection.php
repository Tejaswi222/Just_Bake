
<?php
include("Database.php");

function signUser($FristName,$LastName,$UserName,$Password,$PhoneNumber,$Email){
    
    $dbInstance=new DatabaseClass();
    $insertQuery="INSERT INTO signup (FristName,LastName,UserName,UserPassword,PhoneNumber,Email)
     VALUES ('$FristName','$LastName','$UserName','$Password','$PhoneNumber','$Email')";
    //echo "$insertQuery";
    $result=$dbInstance->ActionQuery($insertQuery);
    //echo "$result";
    if($result)
    {
        return 1;
    }
    else
    {
        return $dbInstance;
    }
}

if(isset($_POST['fName']))
{
    $FristName=$_POST['fName'];
    $LastName=$_POST['lName'];
    $UserName=$_POST['uName'];
    $Password=$_POST['pName'];
    $PhoneNumber=$_POST['phone'];
    $Email=$_POST['email'];
    
    if($FristName!=""&& $LastName!=""&& $UserName!="" && $Email!="" && $Password!="" && $PhoneNumber!="" ){
            
        $registerDetails=signUser($FristName,$LastName,$UserName,$Password,$PhoneNumber,$Email);
            if($registerDetails==1)
            {
                echo "<span style='padding-left:38%;color:white;'>Registration done successfully..! </span>";
                echo "<p></p>";
                $redirect="http://localhost/JustBake%20project/login.php";
                echo "<a style='padding-left:50%;' href='$redirect'>Click here to login</a>";
                
            }
            else
            {
                echo "<span style='padding-left:48%;color:white;'>Registration not done ! </span>";
            }
            
    } else {
        echo"<span style='padding-left:48%;color:white;'>Please enter all details</span>";
    }
    
    
}
?>
