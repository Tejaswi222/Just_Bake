-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 24, 2020 at 01:01 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `custom`
--

CREATE TABLE `custom` (
  `Ocassion` varchar(20) NOT NULL,
  `Caketype` varchar(20) NOT NULL,
  `CakeSize` varchar(20) NOT NULL,
  `Cakeshape` varchar(20) NOT NULL,
  `Nooftiers` varchar(20) NOT NULL,
  `Color` varchar(20) NOT NULL,
  `Flavour` varchar(20) NOT NULL,
  `Filling` varchar(20) NOT NULL,
  `Icing` varchar(20) NOT NULL,
  `Writing_Color` varchar(20) NOT NULL,
  `Writing` varchar(50) NOT NULL,
  `Notes` varchar(50) NOT NULL,
  `Noofcakes` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `custom`
--

INSERT INTO `custom` (`Ocassion`, `Caketype`, `CakeSize`, `Cakeshape`, `Nooftiers`, `Color`, `Flavour`, `Filling`, `Icing`, `Writing_Color`, `Writing`, `Notes`, `Noofcakes`) VALUES
('new occasion', 'eggless', '10inch', 'heart', '4', 'red', 'Rv', 'VC', 'WC', 'orange', 'write this', 'special', ''),
('new occasion', 'eggless', '8inch', 'rectangle', '4', 'red', 'Pineapple', 'CreamCheese', 'Royal Icing', 'orange', 'write this', 'ins', ''),
('new occasion3', 'eggless', 'customsize', 'rectangle', '5', 'gREEN', 'RedVelvet', 'Raspberry', 'Whipped Cream', 'Red', 'Write this on cake', 'Instruction', '');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `FristName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `UserPassword` varchar(20) NOT NULL,
  `PhoneNumber` int(10) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`FristName`, `LastName`, `UserName`, `UserPassword`, `PhoneNumber`, `Email`) VALUES
('', '', '', '', 0, ''),
('', '', '', '', 0, ''),
('Vinitha', 'challa', 'vinithachalla', 'vinithachalla', 469, 'vinithareddychalla96@gmail.com'),
('teju', 'bezawada', 'tejubezawada', 'tejubezawada', 469, 'tejubezawada222@gmail.com'),
('Shyam', 'T', 'shyam', 'asdfgh', 123, 'st@gmail.com'),
('Maniroop', 'D', 'Maniroop', 'asdfgh', 123, 'md@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
