<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
       

</head>
<body align="center">
	
    
	 <h1>Custom your cake with your  own options</h1>
        <div class="formpage">
        	<form action="cost.php" method="POST">
	 	     <p>Ocassion:<input type="text" class="input-field" name="themeid" ></p>
             <p align="center"><u>Cake Type</u></p>
              <input type="radio" class="input-field" name="caketype" id="egg" value="egg">
            <label for="egg">Egg</label>
             <input type="radio" name="caketype" class="input-field" id="eggless" value="eggless">
            <label for="egg">EggLess</label><br><br>
              <p align="center"><u>Cake Size</u></p>
              <input type="radio" class="input-field" name="cakesize" id="6inch" value="6inch">
            <label for="6inch">6inch</label>
              <input type="radio" class="input-field" name="cakesize" id="8inch" value="8inch">
            <label for="8inch">8inch</label>
               <input type="radio" class="input-field" name="cakesize" id="10inch" value="10inch">
            <label for="10inch">10inch</label><br>
                <input type="radio"  class="input-field" name="cakesize" id="halfsheet" value="halfsheet">
            <label for="halfsheet">Halfsheet</label>
              <input type="radio" class="input-field" name="cakesize" id="fullsheet" value="fullsheet">
            <label for="fullsheet">Fullsheet</label>
              <input type="radio" class="input-field" name="cakesize" id="customsize" value="customsize">
            <label for="customsize">Customsize</label><br><br>
               <p align="center"><u>Cake Shape</u></p>
               <input type="radio" class="input-field" name="cakeshape" id="round" value="round">
            <label for="round">Round</label>
               <input type="radio" class="input-field" name="cakeshape" id="rectangle" value="rectangle">
            <label for="rectangle">Rectangle</label><br>
               <input type="radio" class="input-field" name="cakeshape" id="square" value="square">
            <label for="square">Square</label>
               <input type="radio" class="input-field" name="cakeshape" id="heart" value="heart">
            <label for="heart">Heart</label><br><br>
                <p>No.of tires:<input type="text" class="input-field" name="tires" id="tiresid"></p><br>
                <p>Color:<input type="text" class="input-field" name="color" id="colorid"></p><br>
            <label>Flavours</label>
                <select  class="input-field" name="flavour">
                    <option value ="Chocolate">Chocolate </option>
                    <option value ="Vanilla">Vanilla</option>
                    <option value ="RedVelvet">RedVelvet</option>
                    <option value ="Pineapple">Pineapple</option>
                    <option value ="BlackForest">BlackForest</option>
                    <option value ="Strawberry">Strawberry</option> 
                </select>
            <label>Filling</label>
                <select class="input-field" name="filling">
                    <option value ="Chocolate Creme">Chocolate Creme</option>
                    <option value ="Lemon">Lemon</option>
                    <option value ="Vanilla">Vanilla</option>
                    <option value ="Peanut Butter">Peanut Butter</option>
                    <option value ="Raspberry">Raspberry</option>
                    <option value ="Carmel">Carmel</option>
                    <option value ="Mocha">Mocha</option>
                    <option value ="CreamCheese">CreamCheese</option>
                    <option value ="Cookies cream">Cookies cream</option>
                    <option value ="Strawberry">Strawberry</option>
                 </select><br><br>
                  
             <label>Icing</label>
                <select  class="input-field" name="Icing">
                    <option value ="Butter Cream">Butter Cream</option>
                    <option value ="Whipped Cream">Whipped Cream</option>
                    <option value ="Royal Icing">Royal Icing</option>
                </select>
             <lable for="Note">Wirting color</lable>
                 <input type="text"  class="input-field" name="writingcolor" id="WC"><br><br>
            <lable for="Note">Wirting to say</lable>
                 <textarea name="Wirting"  class="input-field" id="writing" rows="3" cols="20"></textarea><br><br>
   
              <lable for="Note">Special Instructions</lable>
                 <textarea name="note" class="input-field id="noteid" rows="5" cols="40"></textarea><br><br>
                  <input type= "submit"class="input-field" name="sub" id="subid" value="Place Order">
                  <input type= "button" name="back" id="btn" value="back" onclick="window.location.href='http://localhost/JustBake%20project/orderpage.php';" > 
         </form>
         </div>

                       
     </body>
     </html>
	