<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        

</head>
<body align="center">
	<nav>
		<div class="menu">
			<a href="homepage.php">Home</a>
			<a href="orderpage.php">Order</a>
			<a href="Aboutuspage.php">AboutUs</a>
		</div>
    </nav>
  
	 <h1>Welcome to JustBake</h1>
	 
	  <p style='color:red;align:center;'>Payment can be done during the pickup</p>
     <p style='color:black;align:center;'>Thank you for shopping</p>
     <form>
      <button type= "button" name="cnt" id="cntid"  onclick="window.location.href='homepage.php';" >Continue Shopping</button> 

</form>
</body>
</html>