<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=Cp1252">
</head>
    <body>
    <?php
    //Data class file
    class DatabaseClass{
        protected static $connection;//This is a property
        
        public function connect(){
            //Try and connect to the database
            if(!isset(self::$connection))//if the connection is not set already
            {
                include("db.php");
                self::$connection=new mysqli($host,$username,$password,$dbname);
            }
            //if the connection was not successful, handle the error
            if(self::$connection===false)
            {
                //handle error- notify the administrator, log to a file, show an error screen, etc.
                return false;
            }
            return self::$connection;
        }//end of function connect
        
        //Query function
        public function Select($query)
        {
            $connection=$this->connect();
            //query the database
            $result=$connection->query($query);
            
            if(!$result)
            {
                return $connection->error;
            }
            else
            {
                return $result;
            }
        }//end of function Select()
        
        public function ActionQuery($sql)
        {
            $connection=$this->connect();
            //query the database
            $result=$connection->query($sql);
            //this result would be a true or a false because there is no data to return in action queries
            
            if($result)
            {
                return $result;
            }
            else {
                return false;
            }
        }//end of method ActionQuery()
        
        public function error()
        {
            //gets the last error from the database
            $connection=$this->connect();
            return $connection->error;
        }//end of function error()
        
    }//end of class
    
	?>
    </body>
  
</html>