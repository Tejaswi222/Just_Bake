<!DOCTYPE html>
<html>
<head>
        <title>JustBake</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style1.css"> 
        <script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>
       

</head>
<body align="center">
<nav>
		<div class="menu">
			<a href="homepage.php">Home</a>
			<a href="orderpage.php">Order</a>
			<a href="Aboutuspage.php">AboutUs</a>
		</div>
    </nav>
 <h1>Welcome to JustBake</h1>
<?php
include("Database.php");

function addCustomCakeDetails($themeid,$caketype,$cakes,$flavour,$Icing,$note){
    
    $dbInstance=new DatabaseClass();
    $insertQuery="INSERT INTO custom (Ocassion,Caketype,Noofcakes,Flavour,Icing,Notes)
     VALUES ('$themeid','$caketype','$cakes','$flavour','$Icing','$note')";
    //echo "$insertQuery";
    $result=$dbInstance->ActionQuery($insertQuery);
    //echo "$result";
    if($result)
    {
        return 1;
    }
    else
    {
        return $dbInstance;
    }
}

function calculateCost($themeid,$caketype,$cakes,$flavour,$Icing,$note){
    $x=0;$y=0;;

        if( $cakes>0){
            $x=($cakes)*3;
        }else{echo"enter valid number";}
        if($note!=""){
            $y=1;
        }else{$y=0;}
        $sum= $x + $y ;
      echo "<p><span style='padding:10%;color:black; align:center;'>Total cost= $".$sum."</span></p> ";  
}


if($_SERVER['REQUEST_METHOD']=='POST'){ 
    
    if(isset($_POST["themeid"]) && isset($_POST["caketype"])
        && isset($_POST["cakes"]) && isset($_POST["flavour"]) && 
        isset($_POST["Icing"])){
        if($_POST["themeid"]!="" && $_POST["caketype"]!="" && $_POST["cakes"]!=""
            && $_POST["flavour"]!="" && $_POST["Icing"]!=""){
           
            $themeid=$_POST['themeid'];
            $caketype=$_POST['caketype'];
            $cakes=$_POST['cakes'];
            $flavour=$_POST['flavour'];
            $Icing=$_POST['Icing'];
            $note=$_POST['note'];
            
           
            
            if($themeid!=""&& $caketype!=""&& $cakes!="" && $flavour!=""&& $Icing!=""){
                
                $customDetails=addCustomCakeDetails($themeid,$caketype,$cakes,$flavour,$Icing,$note);
                if($customDetails==1)
                {
                    
                    calculateCost($themeid,$caketype,$cakes,$flavour,$Icing,$note);
                    echo "<span style='padding:10%;color:black; align:center;'>Custom cake details added successfully..! </span>";
                    echo "<p><span style='padding:10%;color:black; align:center;'>Your cupcakes for ".$themeid." </span></p>";
                    echo "<p><span style='padding:10%;color:black; align:center;'>No. of cakes   ".$cakes." </span></p>";
                    echo "<p><span style='padding:10%;color:black; align:center;'>Flavour of  ".$flavour."</span></p>";
                      
                }
                
                else
                {
                    echo "<span style='padding:10%;color:black;align:center;'>Cake details cannot be added! </span>";
                }
                
            } else {
                echo"<span style='padding:10%;color:black;align:center;'>Please enter all details</span>";
            }
            
        }
        else {
            echo"<span style='padding:10%;color:black;align:center;'>Please enter all details</span>";
        }
    }
    else {
        echo"<span style='padding:10%;color:black;align:center;'>Please enter all details</span>";
    }
}

?>
<form>
       <button type= "button"class="input-field"  onclick= "window.location.href='paymentpage.php'"  name="ok" id="okid" >ok</button>
       <button type= "button" name="back1" id="btn1"  onclick="window.location.href='custompage1.php';" >back</button> 

</form>   
</body>
</html>
 