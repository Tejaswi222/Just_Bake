<!DOCTYPE html>
<html>
<head>
        <title>Login Page</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css"> 
        <script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>
</head>
<body>
       <div class="loginpage">
    <h1 align='center'>Welcome to JustBake</h1>
         <div class="form">
         <div class="button-box">
         <div id="btn"></div> 
         <button type="button" class="toggle-btn" onclick="login()">login</button>
         <button type="button" class="toggle-btn" onclick="signup()">signup</button>
         </div>           
          <form  id="login" class="input-form"action="validate.php" method="POST">
                 <p>Username:<input type="text"class="inputfield" name="username" id="userid" required></p><br>
                 <label for="pwd">Password:</label>
  <input type="password" class="inputfield" id="pwd" name="pwd"required><br><br></p><br>
                 <button type="submit"class="submit" name="login-btn" >Login</button>
                 
            </form>
            <form   id="signup" class="input-form" action="connection.php" method="POST">
              <p>Fristname:<input type="text"class="inputfield"name="fName"id="fNameid" required></p>
              <p>Lastname:<input type="text"class="inputfield"name="lName"id="lNameid" required></p>
              <p>Username:<input type="text"class="inputfield"name="uName"id="uNameid" required></p>
              <p>Create Password:<input type="password"class="inputfield"Name="pName"id="pNameid" required></p>
              <p>PhoneNumber:<input type="tel"class="inputfield"name="phone"id="phoneid"pattern="[0-9]{10}"></p>
              <p>Email:<input type="email"class="inputfield"name="email"id="email"></p><br>
              <button type="submit" class="submit" name="signup-btn" >Create</button>
            </form>
            <span id="result"></span>
          </div>
        </div>
        <script>
        var x= document.getElementById('login');
        var y= document.getElementById('signup');
        var z= document.getElementById('btn');
        function signup(){
       
            x.style.left="-400px";
        	y.style.left="50px";
        	z.style.left="110px";
        	
        }
        function login(){
        	
        	x.style.left="50px";
        	y.style.left="450px";
        	z.style.left="0px";
        	
        }
        
        </script>

</body>
</html>