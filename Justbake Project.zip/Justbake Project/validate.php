<!DOCTYPE html>
<html>
<head>
	<meta charset = 'utf-8'>
	<link rel="stylesheet" type="text/css" href="style.css"/>

	<title>Validate Login Details</title>
	
</head>
<body align="center ">
	<form method ='POST'>
	<?php
	include_once("Database.php");
	
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
	    if(isset($_POST['username']) && isset($_POST['pwd'])){
		        if(trim($_POST['username'])!="" && trim($_POST['pwd'])!=""){
		            $username = trim($_POST['username']);
		            $pwd = trim($_POST['pwd']);
		            checkLoginDetails($username,$pwd);
		    }
		    else{
		        echo"Please Enter Valid input";
		    }
	    }
	}
	function checkLoginDetails($username,$pwd){
	    $dboInstance=new DatabaseClass();
	    $selectQuery="SELECT UserName,UserPassword FROM signup WHERE UserName='".$username."' AND UserPassword='".$pwd."'";
	    
	    try{
	        $result=$dboInstance->Select($selectQuery);
	        if($result)
	        {
	            if(!empty($result) && $result->num_rows>0)
	            {
	                echo "<script> location.href='http://localhost/JustBake%20project/homepage.php'; </script>";
	                exit;
	            }
	            else
	            {
	                echo "<p>No details found</p>";
	            } 
	        }
	    }
	    catch(Exception $e){
	        echo "<script>window.alert(".$e->getMessage().")</script>";
	    }
	}
    ?>
	</form>
</body>
</html>